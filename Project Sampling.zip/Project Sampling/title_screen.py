import pygame
import constants

from level_manager import *
#Three imports where here for other screens, but where removed for this sampling.
from profile_loader import *

class TitleScreen():
    def __init__(self):

        #Profile listings' size, visual fade, x position, and y position initialized.-----------------------------------------------------
        self.slider_text_1_size = 1; self.slider_text_2_size = 10; self.slider_text_3_size = 25; self.slider_text_4_size = 50; self.slider_text_5_size = 25; self.slider_text_6_size = 10; self.slider_text_7_size = 1

        self.slider_text_1_fade = 255; self.slider_text_2_fade = 175; self.slider_text_3_fade = 50; self.slider_text_4_fade = 0; self.slider_text_5_fade = 50; self.slider_text_6_fade = 175; self.slider_text_7_fade = 255

        self.slider_text_1_x = 80; self.slider_text_2_x = 80; self.slider_text_3_x = 130; self.slider_text_4_x = 270; self.slider_text_5_x = 500; self.slider_text_6_x = 620; self.slider_text_7_x = 625
        self.slider_text_1_y = 300; self.slider_text_2_y = 305; self.slider_text_3_y = 292; self.slider_text_4_y = 270; self.slider_text_5_y = 292; self.slider_text_6_y = 305; self.slider_text_7_y = 300

        #Copies of those figures are made to be unaltered so the initial values can be remembered by the system.--------------------------
        self.remembered_x_1 = self.slider_text_1_x; self.remembered_x_2 = self.slider_text_2_x; self.remembered_x_3 = self.slider_text_3_x; self.remembered_x_4 = self.slider_text_4_x; self.remembered_x_5 = self.slider_text_5_x; self.remembered_x_6 = self.slider_text_6_x; self.remembered_x_7 = self.slider_text_7_x
        self.remembered_y_1 = self.slider_text_1_y; self.remembered_y_2 = self.slider_text_2_y; self.remembered_y_3 = self.slider_text_3_y; self.remembered_y_4 = self.slider_text_4_y; self.remembered_y_5 = self.slider_text_5_y; self.remembered_y_6 = self.slider_text_6_y; self.remembered_y_7 = self.slider_text_7_y
        self.remembered_size_1 = self.slider_text_1_size; self.remembered_size_2 = self.slider_text_2_size; self.remembered_size_3 = self.slider_text_3_size; self.remembered_size_4 = self.slider_text_4_size; self.remembered_size_5 = self.slider_text_5_size; self.remembered_size_6 = self.slider_text_6_size; self.remembered_size_7 = self.slider_text_7_size
        self.remembered_fade_1 = self.slider_text_1_fade; self.remembered_fade_2 = self.slider_text_2_fade; self.remembered_fade_3 = self.slider_text_3_fade; self.remembered_fade_4 = self.slider_text_4_fade; self.remembered_fade_5 = self.slider_text_5_fade; self.remembered_fade_6 = self.slider_text_6_fade; self.remembered_fade_7 = self.slider_text_7_fade
        

        self.profile_switch_animation_rate = 10     #Controls the speed of the profile switching animation.

        self.profile_switch_acceptence_margin = 5   #Controls how close the animation has to be to completion before snapping the new order
                                                    #in place, backend loading the profile, and allowing another animation initiation.

        self.profile_array = []
        self.profile = Profile()  #loads profile
        last_loaded_profile_number = Profile.get_active_profile(self)

        Profile.set_active_profile(self, 1)
        self.profile = Profile()
        while(self.profile.id != ""):
            self.profile_array.append(self.profile)
            self.active_profile_number = Profile.get_active_profile(self)
            Profile.set_active_profile(self,self.active_profile_number + 1)
            self.profile = Profile()
        
        Profile.set_active_profile(self,last_loaded_profile_number)
        self.active_profile_number = Profile.get_active_profile(self)

        self.slider_profile_name_1 = self.profile_array[(self.active_profile_number - 4) % len(self.profile_array)].name
        self.slider_profile_name_2 = self.profile_array[(self.active_profile_number - 3) % len(self.profile_array)].name
        self.slider_profile_name_3 = self.profile_array[(self.active_profile_number - 2) % len(self.profile_array)].name
        self.slider_profile_name_4 = self.profile_array[(self.active_profile_number - 1) % len(self.profile_array)].name#<---Middle of the slider, and selected profile.
        self.slider_profile_name_5 = self.profile_array[(self.active_profile_number + 0) % len(self.profile_array)].name
        self.slider_profile_name_6 = self.profile_array[(self.active_profile_number + 1) % len(self.profile_array)].name
        self.slider_profile_name_7 = self.profile_array[(self.active_profile_number + 2) % len(self.profile_array)].name

        self.is_selecting_left = False
        self.is_selecting_right = False
        
        

    def handle_keyboard_event(self, event):
        
        if event.type == pygame.KEYDOWN:
            # An argument can be made to place leaving the level in the main loop
            if event.key == pygame.K_ESCAPE:
                LevelManager().leave_level()
            elif event.key == pygame.K_p:
                LevelManager().load_level(GameScreen())
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            print(pos)
            '''
            The controls for the buttons for the menu where here but were removed for this sampling.
            '''
            if (pos[0] > 477) and (pos[0] < 592) and (pos[1] > 289) and (pos[1] < 322):  #Zgflex
                print("Profile slider selected to select to the right 1")
                
                self.is_selecting_right = True


            elif (pos[0] > 128) and (pos[0] < 242) and (pos[1] > 295) and (pos[1] < 316):  #Zgflex
                print("Profile slider selected to select to the left 1")

                self.is_selecting_left = True
                


    
    def update(self):

        if self.is_selecting_right and not self.is_selecting_left:#Name to the right selected, slides names to the left and loads next profile from the file----------

            if self.slider_text_2_x > self.remembered_x_1:
                self.slider_text_2_x -= ((self.slider_text_2_x - self.remembered_x_1) / (self.profile_switch_animation_rate))
            if self.slider_text_2_y < self.remembered_y_1:
                self.slider_text_2_y += ((self.remembered_y_1 - self.slider_text_2_y) / (self.profile_switch_animation_rate))
            if self.slider_text_2_size > self.remembered_size_1:
                self.slider_text_2_size -= ((self.slider_text_2_size - self.remembered_size_1) / (self.profile_switch_animation_rate))
            if self.slider_text_2_fade < self.remembered_fade_1:
                self.slider_text_2_fade += ((self.remembered_fade_1 - self.slider_text_2_fade) / (self.profile_switch_animation_rate))
            
            if self.slider_text_3_x > self.remembered_x_2:
                self.slider_text_3_x -= ((self.slider_text_3_x - self.remembered_x_2) / (self.profile_switch_animation_rate))
            if self.slider_text_3_y < self.remembered_y_2:
                self.slider_text_3_y += ((self.remembered_y_2 - self.slider_text_3_y) / (self.profile_switch_animation_rate))
            if self.slider_text_3_size > self.remembered_size_2:
                self.slider_text_3_size -= ((self.slider_text_3_size - self.remembered_size_2) / (self.profile_switch_animation_rate))
            if self.slider_text_3_fade < self.remembered_fade_2:
                self.slider_text_3_fade += ((self.remembered_fade_2 - self.slider_text_3_fade) / (self.profile_switch_animation_rate))
            
            if self.slider_text_4_x > self.remembered_x_3:
                self.slider_text_4_x -= ((self.slider_text_4_x - self.remembered_x_3) / (self.profile_switch_animation_rate))
            if self.slider_text_4_y < self.remembered_y_3:
                self.slider_text_4_y += ((self.remembered_y_5 - self.slider_text_4_y) / (self.profile_switch_animation_rate))
            if self.slider_text_4_size > self.remembered_size_5:
                self.slider_text_4_size -= ((self.slider_text_4_size - self.remembered_size_5) / (self.profile_switch_animation_rate))
            if self.slider_text_4_fade < self.remembered_fade_5:
                self.slider_text_4_fade += ((self.remembered_fade_5 - self.slider_text_4_fade) / (self.profile_switch_animation_rate))
            
            if self.slider_text_5_x > self.remembered_x_4:
                self.slider_text_5_x -= ((self.slider_text_5_x - self.remembered_x_4) / (self.profile_switch_animation_rate))
            if self.slider_text_5_y > self.remembered_y_4:
                self.slider_text_5_y -= ((self.slider_text_5_y - self.remembered_y_4) / (self.profile_switch_animation_rate))
            if self.slider_text_5_size < self.remembered_size_4:
                self.slider_text_5_size += ((self.slider_text_4_size - self.remembered_size_5) / (self.profile_switch_animation_rate))
            if self.slider_text_5_fade > self.remembered_fade_4:
                self.slider_text_5_fade -= ((self.remembered_fade_5 - self.slider_text_4_fade) / (self.profile_switch_animation_rate))

            if self.slider_text_6_x > self.remembered_x_5:
                self.slider_text_6_x -= ((self.slider_text_6_x - self.remembered_x_5) / (self.profile_switch_animation_rate))
            if self.slider_text_6_y > self.remembered_y_5:
                self.slider_text_6_y -= ((self.remembered_y_6 - self.slider_text_5_y) / (self.profile_switch_animation_rate))
            if self.slider_text_6_size < self.remembered_size_5:
                self.slider_text_6_size += ((self.remembered_size_5 - self.slider_text_6_size) / (self.profile_switch_animation_rate))
            if self.slider_text_6_fade > self.remembered_fade_5:
                self.slider_text_6_fade -= ((self.remembered_fade_6 - self.slider_text_5_fade) / (self.profile_switch_animation_rate))

            if self.slider_text_7_x > self.remembered_x_6:
                self.slider_text_7_x -= ((self.slider_text_7_x - self.remembered_x_6) / (self.profile_switch_animation_rate))
            if self.slider_text_7_y > self.remembered_y_6:
                self.slider_text_7_y -= ((self.remembered_y_7 - self.slider_text_6_y) / (self.profile_switch_animation_rate))
            if self.slider_text_7_size < self.remembered_size_6:
                self.slider_text_7_size += ((self.remembered_size_6 - self.slider_text_7_size) / (self.profile_switch_animation_rate))
            if self.slider_text_7_fade > self.remembered_fade_6:
                self.slider_text_7_fade -= ((self.remembered_fade_7 - self.slider_text_6_fade) / (self.profile_switch_animation_rate))

            if self.slider_text_4_x <= self.remembered_x_3 + self.profile_switch_acceptence_margin:
                self.is_selecting_right = False
                if self.active_profile_number < len(self.profile_array):
                    self.active_profile_number += 1
                    Profile.set_active_profile(self,self.active_profile_number)
                    print(self.active_profile_number)
                else:
                    self.active_profile_number = 1
                    Profile.set_active_profile(self,self.active_profile_number)
                    print(self.active_profile_number)

                self.slider_profile_name_1 = self.profile_array[(self.active_profile_number - 4) % len(self.profile_array)].name
                self.slider_profile_name_2 = self.profile_array[(self.active_profile_number - 3) % len(self.profile_array)].name
                self.slider_profile_name_3 = self.profile_array[(self.active_profile_number - 2) % len(self.profile_array)].name
                self.slider_profile_name_4 = self.profile_array[(self.active_profile_number - 1) % len(self.profile_array)].name#<---
                self.slider_profile_name_5 = self.profile_array[(self.active_profile_number + 0) % len(self.profile_array)].name
                self.slider_profile_name_6 = self.profile_array[(self.active_profile_number + 1) % len(self.profile_array)].name
                self.slider_profile_name_7 = self.profile_array[(self.active_profile_number + 2) % len(self.profile_array)].name

                self.slider_text_1_size = 1; self.slider_text_2_size = 10; self.slider_text_3_size = 25; self.slider_text_4_size = 50; self.slider_text_5_size = 25; self.slider_text_6_size = 10; self.slider_text_7_size = 1

                self.slider_text_1_fade = 255; self.slider_text_2_fade = 175; self.slider_text_3_fade = 50; self.slider_text_4_fade = 0; self.slider_text_5_fade = 50; self.slider_text_6_fade = 175; self.slider_text_7_fade = 255

                self.slider_text_1_x = 80; self.slider_text_2_x = 80; self.slider_text_3_x = 130; self.slider_text_4_x = 270; self.slider_text_5_x = 500; self.slider_text_6_x = 620; self.slider_text_7_x = 625
                self.slider_text_1_y = 300; self.slider_text_2_y = 305; self.slider_text_3_y = 292; self.slider_text_4_y = 270; self.slider_text_5_y = 292; self.slider_text_6_y = 305; self.slider_text_7_y = 300

                

        if self.is_selecting_left and not self.is_selecting_right:#Name to the left selected, slides names to the right and loads next profile from the file----------

            if self.slider_text_1_x < self.remembered_x_2:
                self.slider_text_1_x += ((self.remembered_x_2 - self.slider_text_1_x) / self.profile_switch_animation_rate)
            if self.slider_text_1_y > self.remembered_y_2:
                self.slider_text_1_y -= ((self.slider_text_1_y - self.remembered_y_2) / self.profile_switch_animation_rate)
            if self.slider_text_1_size < self.remembered_size_2:
                self.slider_text_1_size -= ((self.slider_text_1_size - self.remembered_size_2) / self.profile_switch_animation_rate)
            if self.slider_text_1_fade > self.remembered_fade_2:
                self.slider_text_1_fade += ((self.remembered_fade_2 - self.slider_text_1_fade) / self.profile_switch_animation_rate)  

            if self.slider_text_2_x < self.remembered_x_3:
                self.slider_text_2_x += ((self.remembered_x_3 - self.slider_text_2_x) / self.profile_switch_animation_rate)
            if self.slider_text_2_y > self.remembered_y_3:
                self.slider_text_2_y -= ((self.slider_text_2_y - self.remembered_y_3) / self.profile_switch_animation_rate)
            if self.slider_text_2_size < self.remembered_size_3:
                self.slider_text_2_size -= ((self.slider_text_2_size - self.remembered_size_3) / self.profile_switch_animation_rate)
            if self.slider_text_2_fade > self.remembered_fade_3:
                self.slider_text_2_fade += ((self.remembered_fade_3 - self.slider_text_2_fade) / self.profile_switch_animation_rate)            
            
            if self.slider_text_3_x < self.remembered_x_4:
                self.slider_text_3_x += ((self.remembered_x_4 - self.slider_text_3_x) / self.profile_switch_animation_rate)
            if self.slider_text_3_y > self.remembered_y_4:
                self.slider_text_3_y -= ((self.slider_text_3_y - self.remembered_y_4) / self.profile_switch_animation_rate)
            if self.slider_text_3_size < self.remembered_size_4:
                self.slider_text_3_size -= ((self.slider_text_3_size - self.remembered_size_4) / self.profile_switch_animation_rate)
            if self.slider_text_3_fade > self.remembered_fade_4:
                self.slider_text_3_fade += ((self.remembered_fade_4 - self.slider_text_3_fade) / self.profile_switch_animation_rate)

            if self.slider_text_4_x < self.remembered_x_5:
                self.slider_text_4_x += ((self.remembered_x_5 - self.slider_text_4_x) / self.profile_switch_animation_rate)
            if self.slider_text_4_y < self.remembered_y_3:
                self.slider_text_4_y += ((self.remembered_y_3 - self.slider_text_4_y) / self.profile_switch_animation_rate)
            if self.slider_text_4_size > self.remembered_size_5:
                self.slider_text_4_size -= ((self.slider_text_4_size - self.remembered_size_5) / self.profile_switch_animation_rate)
            if self.slider_text_4_fade < self.remembered_fade_5:
                self.slider_text_4_fade += ((self.remembered_fade_5 - self.slider_text_4_fade) / self.profile_switch_animation_rate)

            if self.slider_text_5_x < self.remembered_x_6:
                self.slider_text_5_x += ((self.remembered_x_6 - self.slider_text_5_x) / self.profile_switch_animation_rate)
            if self.slider_text_5_y < self.remembered_y_6:
                self.slider_text_5_y += ((self.remembered_y_6 - self.slider_text_5_y) / self.profile_switch_animation_rate)
            if self.slider_text_5_size > self.remembered_size_6:
                self.slider_text_5_size -= ((self.slider_text_5_size - self.remembered_size_6) / self.profile_switch_animation_rate)
            if self.slider_text_5_fade < self.remembered_fade_6:
                self.slider_text_5_fade += ((self.remembered_fade_6 - self.slider_text_5_fade) / self.profile_switch_animation_rate)

            if self.slider_text_6_x < self.remembered_x_7:
                self.slider_text_6_x += ((self.remembered_x_7 - self.slider_text_6_x) / self.profile_switch_animation_rate)
            if self.slider_text_6_y < self.remembered_y_7:
                self.slider_text_6_y += ((self.remembered_y_7 - self.slider_text_6_y) / self.profile_switch_animation_rate)
            if self.slider_text_6_size > self.remembered_size_7:
                self.slider_text_6_size -= ((self.slider_text_6_size - self.remembered_size_7) / self.profile_switch_animation_rate)
            if self.slider_text_6_fade < self.remembered_fade_7:
                self.slider_text_6_fade += ((self.remembered_fade_7 - self.slider_text_6_fade) / self.profile_switch_animation_rate)

            if self.slider_text_4_x >= self.remembered_x_5 - self.profile_switch_acceptence_margin:
                self.is_selecting_left = False
                if self.active_profile_number > 1:
                    self.active_profile_number -= 1
                    Profile.set_active_profile(self,self.active_profile_number)
                    print(self.active_profile_number)
                else:
                    self.active_profile_number = len(self.profile_array)
                    Profile.set_active_profile(self,self.active_profile_number)
                    print(self.active_profile_number)

                self.slider_profile_name_1 = self.profile_array[(self.active_profile_number - 4) % len(self.profile_array)].name
                self.slider_profile_name_2 = self.profile_array[(self.active_profile_number - 3) % len(self.profile_array)].name
                self.slider_profile_name_3 = self.profile_array[(self.active_profile_number - 2) % len(self.profile_array)].name
                self.slider_profile_name_4 = self.profile_array[(self.active_profile_number - 1) % len(self.profile_array)].name#<---
                self.slider_profile_name_5 = self.profile_array[(self.active_profile_number + 0) % len(self.profile_array)].name
                self.slider_profile_name_6 = self.profile_array[(self.active_profile_number + 1) % len(self.profile_array)].name
                self.slider_profile_name_7 = self.profile_array[(self.active_profile_number + 2) % len(self.profile_array)].name

                self.slider_text_1_size = 1; self.slider_text_2_size = 10; self.slider_text_3_size = 25; self.slider_text_4_size = 50; self.slider_text_5_size = 25; self.slider_text_6_size = 10; self.slider_text_7_size = 1

                self.slider_text_1_fade = 255; self.slider_text_2_fade = 175; self.slider_text_3_fade = 50; self.slider_text_4_fade = 0; self.slider_text_5_fade = 50; self.slider_text_6_fade = 175; self.slider_text_7_fade = 255

                self.slider_text_1_x = 80; self.slider_text_2_x = 80; self.slider_text_3_x = 130; self.slider_text_4_x = 270; self.slider_text_5_x = 500; self.slider_text_6_x = 620; self.slider_text_7_x = 625
                self.slider_text_1_y = 300; self.slider_text_2_y = 305; self.slider_text_3_y = 292; self.slider_text_4_y = 270; self.slider_text_5_y = 292; self.slider_text_6_y = 305; self.slider_text_7_y = 300

        
    def draw(self, screen):
        
        

        # Clears the screen for the menu------------------------------------------
        screen.fill((235,235,235))
        
        slider_font_1 = pygame.font.SysFont('Times New Roman', int(self.slider_text_1_size), False, False)
        slider_font_2 = pygame.font.SysFont('Times New Roman', int(self.slider_text_2_size), False, False)
        slider_font_3 = pygame.font.SysFont('Times New Roman', int(self.slider_text_3_size), False, False)
        slider_font_4 = pygame.font.SysFont('Times New Roman', int(self.slider_text_4_size), False, False)
        slider_font_5 = pygame.font.SysFont('Times New Roman', int(self.slider_text_5_size), False, False)
        slider_font_6 = pygame.font.SysFont('Times New Roman', int(self.slider_text_6_size), False, False)
        slider_font_7 = pygame.font.SysFont('Times New Roman', int(self.slider_text_7_size), False, False)
        
        self.slider_text_1 = slider_font_1.render(self.slider_profile_name_1 , True, (self.slider_text_1_fade, self.slider_text_1_fade, self.slider_text_1_fade), (235,235,235))
        self.slider_text_2 = slider_font_2.render(self.slider_profile_name_2 , True, (self.slider_text_2_fade, self.slider_text_2_fade, self.slider_text_2_fade), (235,235,235))
        self.slider_text_3 = slider_font_3.render(self.slider_profile_name_3 , True, (self.slider_text_3_fade, self.slider_text_3_fade, self.slider_text_3_fade), (235,235,235))
        self.slider_text_4 = slider_font_4.render(self.slider_profile_name_4 , True, (self.slider_text_4_fade, self.slider_text_4_fade, self.slider_text_4_fade), (235,235,235))
        self.slider_text_5 = slider_font_5.render(self.slider_profile_name_5 , True, (self.slider_text_5_fade, self.slider_text_5_fade, self.slider_text_5_fade), (235,235,235))
        self.slider_text_6 = slider_font_6.render(self.slider_profile_name_6 , True, (self.slider_text_6_fade, self.slider_text_6_fade, self.slider_text_6_fade), (235,235,235))
        self.slider_text_7 = slider_font_7.render(self.slider_profile_name_7 , True, (self.slider_text_7_fade, self.slider_text_7_fade, self.slider_text_7_fade), (235,235,235))
        
        screen.blit(self.slider_text_1, [self.slider_text_1_x, self.slider_text_1_y])
        screen.blit(self.slider_text_2, [self.slider_text_2_x, self.slider_text_2_y])
        screen.blit(self.slider_text_3, [self.slider_text_3_x, self.slider_text_3_y])
        screen.blit(self.slider_text_4, [self.slider_text_4_x, self.slider_text_4_y])
        screen.blit(self.slider_text_5, [self.slider_text_5_x, self.slider_text_5_y])
        screen.blit(self.slider_text_6, [self.slider_text_6_x, self.slider_text_6_y])
        screen.blit(self.slider_text_7, [self.slider_text_7_x, self.slider_text_7_y])


        self.profile = Profile()
        profile_details_font = pygame.font.SysFont('Times New Roman', 20, False, False)
        self.profile_details_text_1 = profile_details_font.render("currency: " + self.profile.currency , True, (0, 0, 0), (235,235,235))
        self.profile_details_text_2 = profile_details_font.render("kills: " + self.profile.zombies_killed , True, (0, 0, 0), (235,235,235))
        self.profile_details_text_3 = profile_details_font.render("second currency: " + self.profile.second_currency , True, (0, 0, 0), (235,235,235))
        self.profile_details_text_4 = profile_details_font.render("died: " + self.profile.players_killed , True, (0, 0, 0), (235,235,235))
        screen.blit(self.profile_details_text_1, [238, 528])
        screen.blit(self.profile_details_text_2, [465, 528])
        screen.blit(self.profile_details_text_3, [238, 558])
        screen.blit(self.profile_details_text_4, [465, 558])
        

        '''
        The image blitting for the menu items where here, but where removed for this sampling.
        '''






#created by Benjamin Reagan
