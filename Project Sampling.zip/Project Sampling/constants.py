
# Define some colors
BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
GREEN = (  0, 255,   0)

# Set the height and width of the screen
SCREEN_WIDTH = 740
SCREEN_HEIGHT = 740

