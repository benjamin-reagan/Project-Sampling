'''
This class was made so stored profiles on a file named profiles.pr can be read from and written to as if they were python objects.  
To change the desired parts of the file, one MUST use the methods given i.e. write() instead using python's direct argument access i.e. profile.id
Currently, this loader can read any number of groups of information from the file, but at the time of this writing, there are 5 "profile" sections
and the ability to easily add more was to be soon implemented.
'''
class Profile:

    def __init__(self):
        
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())         #retrieves the active profile number from the disk.
        active_profile.close()

        
        profiles_file = open('profiles/profiles.pr', 'r+')

        profiles_file.seek(765 * (active_profile_number - 1))#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...

        self.name = profiles_file.readline().rstrip('\n%')
        self.id = profiles_file.readline().rstrip('\n%')
        self.picture = profiles_file.readline().rstrip('\n%')
        self.zombies_killed = profiles_file.readline().rstrip('\n%')
        self.raptors_killed = profiles_file.readline().rstrip('\n%')
        self.players_killed = profiles_file.readline().rstrip('\n%')
        self.favored_weapon = profiles_file.readline().rstrip('\n%')
        self.killed_most_by = profiles_file.readline().rstrip('\n%')
        self.currency = profiles_file.readline().rstrip('\n%')
        self.second_currency = profiles_file.readline().rstrip('\n%')
        self.bonus_1_purchased = profiles_file.readline().rstrip('\n%')
        self.bonus_2_purchased = profiles_file.readline().rstrip('\n%')
        self.bonus_3_purchased = profiles_file.readline().rstrip('\n%')
        self.bonus_4_purchased = profiles_file.readline().rstrip('\n%')
        self.bonus_5_purchased = profiles_file.readline().rstrip('\n%')      #To add more attributes and data to be stored, just add more of these lines 
        profiles_file.close()                                                #and add another 'write' method copying the ones below.
        

    def get_active_profile(self):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())             #retrieves the active profile number from the disk.
        active_profile.close()
        return active_profile_number

    def set_active_profile(self, new_number):
        active_profile = open('profiles/active.file', 'w')
        active_profile.write(str(new_number))               #writes the new active profile number from the disk.
        active_profile.close()

    def get_selected_level(self):
        selected_level_file = open('profiles/selected_level.file', 'r')
        level = selected_level_file.readline().rstrip('\n%')             #retrieves the selected level layout from the disk.
        selected_level_file.close()
        return level

    def set_selected_level(self, new_level):
        selected_level_file = open('profiles/selected_level.file', 'w')
        filler_length = 50 - len(new_level)  #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_level += '%'                 #new_level is now desecrated and added to for the appropriate amount of filler.
        
        selected_level_file.write(new_level)   #new_level with filler is now written to the file
        selected_level_file.close()
        print('done')

    def write_name(self, new_name):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())             #retrieves the active profile number from the disk.
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        print('rewriting profile name')
        self.name = new_name                #Object updated with true new name.
        filler_length = 50 - len(new_name)  #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_name += '%'                 #new_name is now desecrated and added to for the appropriate amount of filler.

        profiles_file.seek((765 * (active_profile_number - 1)) + 0)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        profiles_file.write(new_name)   #new_name with filler is now written to the file
        profiles_file.close()

    def write_id(self, new_id):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.id = new_id                    #Object updated with true new id.
        filler_length = 50 - len(new_id)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_id += '%'                 #new_id is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 51)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile id')
        profiles_file.write(str(new_id))
        profiles_file.close()

def write_picture(self, new_picture):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.picture = new_picture                   #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_picture)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_picture += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 101)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile picture number')
        profiles_file.write(str(new_picture))
        profiles_file.close()

def write_zombies_killed(self, new_zombies_killed):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.zombies_killed = new_zombies_killed                   #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_zombies_killed)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_zombies_killed += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 151)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile zombies killed number')
        profiles_file.write(str(new_zombies_killed))
        profiles_file.close()

def write_raptors_killed(self, new_raptors_killed):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.raptors_killed = new_raptors_killed                   #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_raptors_killed)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_raptors_killed += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 201)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile raptors killed number')
        profiles_file.write(str(new_raptors_killed))
        profiles_file.close()

def write_players_killed(self, new_players_killed):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.players_killed = new_players_killed                   #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_players_killed)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_players_killed += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 251)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile players killed number')
        profiles_file.write(str(new_players_killed))
        profiles_file.close()

def write_favored_weapon(self, new_favored_weapon):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.favored_weapon = new_favored_weapon                 #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_favored_weapon)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_favored_weapon += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 301)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile favored weapon')
        profiles_file.write(str(new_favored_weapon))
        profiles_file.close()

def write_killed_most_by(self, new_killed_most_by):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.killed_most_by = new_killed_most_by                #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_killed_most_by)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_killed_most_by += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 351)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile killed most by')
        profiles_file.write(str(new_killed_most_by))
        profiles_file.close()

def write_currency(self, new_currency):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.currency = new_currency               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_currency)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_currency += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 401)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile currency')
        profiles_file.write(str(new_currency))
        profiles_file.close()

def write_second_currency(self, new_second_currency):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.second_currency = new_second_currency               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_second_currency)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_second_currency += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 451)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile second currency')
        profiles_file.write(str(new_second_currency))
        profiles_file.close()
        
def write_bonus_1_purchased(self, new_bonus_1_purchased):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.bonus_1_purchased = new_bonus_1_purchased               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_bonus_1_purchased)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_bonus_1_purchased += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 501)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile bonus_1_purchased')
        profiles_file.write(str(new_bonus_1_purchased))
        profiles_file.close()

def write_bonus_2_purchased(self, new_bonus_2_purchased):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.bonus_2_purchased = new_bonus_2_purchased               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_bonus_2_purchased)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_bonus_2_purchased += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 551)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile bonus_2_purchased')
        profiles_file.write(str(new_bonus_2_purchased))
        profiles_file.close()

def write_bonus_3_purchased(self, new_bonus_3_purchased):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.bonus_3_purchased = new_bonus_3_purchased               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_bonus_3_purchased)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_bonus_3_purchased += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 601)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile bonus_3_purchased')
        profiles_file.write(str(new_bonus_3_purchased))
        profiles_file.close()

def write_bonus_4_purchased(self, new_bonus_4_purchased):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.bonus_4_purchased = new_bonus_4_purchased               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_bonus_4_purchased)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_bonus_4_purchased += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 651)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile bonus_4_purchased')
        profiles_file.write(str(new_bonus_4_purchased))
        profiles_file.close()

def write_bonus_5_purchased(self, new_bonus_5_purchased):
        active_profile = open('profiles/active.file', 'r')
        active_profile_number = int(active_profile.readline())
        active_profile.close()
        profiles_file = open('profiles/profiles.pr', 'r+')
        self.bonus_5_purchased = new_bonus_5_purchased               #Object updated with true new variable for main memory.
        filler_length = 50 - len(new_bonus_5_purchased)    #remaining space calculated to be filled with filler
        for i in range(0, filler_length):
            new_bonus_5_purchased += '%'                 #The variable is now desecrated and added to for the appropriate amount of filler.
        
        profiles_file.seek((765 * (active_profile_number - 1)) + 701)#writing pointer is put to the right spot in the file. 0=profile1, 765=2, 1530=3, 2295=4, 3060=5 ect...
        
        print('rewriting profile bonus_5_purchased')
        profiles_file.write(str(new_bonus_5_purchased))
        profiles_file.close()
#created by Benjamin Reagan
